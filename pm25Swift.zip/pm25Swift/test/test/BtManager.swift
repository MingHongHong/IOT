import Foundation
import CoreBluetooth

class BtManager : NSObject {
    var mCBCentralManager: CBCentralManager!
    
    override init() {
        super.init();
        initCBCentralManager();
    }
    
    internal func initCBCentralManager() {
        mCBCentralManager = CBCentralManager(delegate: self, queue: nil,
                                             options:[CBCentralManagerOptionShowPowerAlertKey: true]);
    }
}

extension BtManager : CBCentralManagerDelegate {
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == CBManagerState.poweredOn {
            central.scanForPeripherals(withServices: nil, options: nil)
        } else {
            print("Bluetooth not available.")
        }
    }

    
}
